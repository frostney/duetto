{ CLI.Options — option-object base classes + a fluent registry.

  LWPT-canonical per ADR-0017 (descended from a GocciaScript-era
  copy; the GocciaScript-engine-specific option groups Engine /
  Coverage / Profiler were dropped during extraction because they
  describe the JS engine's CLI surface — execution mode, source
  type, coverage formats, bytecode-profiler modes — none of which
  LWPT has. Types were also un-prefixed: the `TGoccia` prefix is
  gone; types live in the CLI namespace now). See docs/contributor/packages.md.

  Surface kept:
    - TParseError                  — raised on user input errors
    - TOptionBase + subclasses     — Flag / String / OptionalString /
                                     Integer / Int64 / Repeatable / Enum<T>
    - TOptionArray                 — flat array; the consumer-facing
                                     shape that ParseCommandLine eats
    - TOptionList                  — fluent registry that owns the
                                     options added to it; .Options
                                     returns a copy of their order

  No Generics.* unit: every host that uses this unit, directly or through
  CLI.Parser / CLI.Help / CLI.Subcommands, would link that unit closure
  and run its initialization at every start. TOptionList keeps its items
  in a plain array instead (#419).

  Lives under the CLI namespace (no LWPT prefix) so it can graduate
  into a standalone reusable package alongside CLI.Parser /
  CLI.Subcommands / CLI.Prompts / CLI.Help when the LWPT bootstrap
  arc lets us replace vendoring with managed deps (see ADR-0006). }
unit CLI.Options;

{$I Shared.inc}

interface

uses
  Classes,
  SysUtils,
  TypInfo;

type
  TParseError = class(Exception);

  TOptionBase = class
  private
    FLongName: string;
    FShortName: string;
    FConfigName: string;
    FHelpText: string;
    FGroup: string;
    FPresent: Boolean;
    FFromCommandLine: Boolean;
    FAllowAttachedShortValue: Boolean;
  public
    constructor Create(const ALongName, AHelpText: string; const AGroup: string = '');

    procedure Apply(const AValue: string); virtual; abstract;
    { Applies one occurrence from the command line. AHasEquals tells
      `--name=` (True, empty AValue) from `--name` (False); it is False for
      a separated value (`--name value`, `-n value`) and an attached short
      value (`-nvalue`). The parser calls this, never Apply; the default
      forwards AValue to Apply, so a subclass that overrides only Apply
      keeps working. }
    procedure ApplyExplicit(const AValue: string;
      const AHasEquals: Boolean); virtual;
    { Whether the option takes the next argument as its value when it is
      named without one (`--name value`, `-n value`). True by default;
      False for a flag and for an optional-value option, which then take a
      value only as `--name=value` (or an opted-in attached short value). }
    function ConsumesSeparateValue: Boolean; virtual;
    function FormatForHelp: string; virtual; abstract;
    { The option as help lists it: FormatHelpLabel of its short name and
      FormatForHelp (`-o, --output=<value>`). Every help surface built
      from an option uses it, so they cannot drift apart. }
    function HelpLabel: string;
    function ValidValues: string; virtual;

    { Mark this option as present without applying a value.
      Used by the config layer to record that a key existed in the
      config file even when no concrete values were produced (e.g.
      an empty array). }
    procedure MarkPresent;

    { Mark this option as having been set by the command line.
      Called after ParseCommandLine so that per-file config can
      distinguish CLI-set values from root-config-set values. }
    procedure MarkFromCommandLine;

    property LongName: string read FLongName;
    property ShortName: string read FShortName write FShortName;
    { When True, a short option other than a flag accepts its value in
      the same argument (`-dDEBUG`, `-Fusource`). A separated value stays
      available to every option whose ConsumesSeparateValue is True. }
    property AllowAttachedShortValue: Boolean read FAllowAttachedShortValue
      write FAllowAttachedShortValue;
    { Alternate name used in config files when different from LongName.
      When empty, config files use LongName as usual. }
    property ConfigName: string read FConfigName write FConfigName;
    property HelpText: string read FHelpText;
    property Group: string read FGroup;
    property Present: Boolean read FPresent;
    property FromCommandLine: Boolean read FFromCommandLine;
  end;

  TOptionArray = array of TOptionBase;

  TFlagOption = class(TOptionBase)
  public
    procedure Apply(const AValue: string); override;
    function ConsumesSeparateValue: Boolean; override;
    function FormatForHelp: string; override;
  end;

  TStringOption = class(TOptionBase)
  private
    FValue: string;
  public
    procedure Apply(const AValue: string); override;
    function FormatForHelp: string; override;

    function ValueOr(const ADefault: string): string;

    property Value: string read FValue;
  end;

  { An option whose value is optional: `--hot` sets it without a value,
    `--hot=` with an empty one and `--hot=restart` with `restart`. It never
    takes the next argument as its value. Present tells whether it was
    given, HasValue whether a value came with it; Value is empty without
    one, and so is ValueOr once the option is present. A direct Apply, as
    from a config file, counts as a value; MarkPresent does not. A
    subclass may override Apply, which ApplyExplicit calls for every
    occurrence: `--hot` reaches it with an empty value, like `--hot=`, and
    HasValue is set only after it returns. A subclass that must tell the
    two apart overrides ApplyExplicit and reads AHasEquals. }
  TOptionalStringOption = class(TStringOption)
  private
    FHasValue: Boolean;
  public
    procedure Apply(const AValue: string); override;
    procedure ApplyExplicit(const AValue: string;
      const AHasEquals: Boolean); override;
    function ConsumesSeparateValue: Boolean; override;
    function FormatForHelp: string; override;

    property HasValue: Boolean read FHasValue;
  end;

  TIntegerOption = class(TOptionBase)
  private
    FValue: Integer;
  public
    procedure Apply(const AValue: string); override;
    function FormatForHelp: string; override;

    function ValueOr(const ADefault: Integer): Integer;

    property Value: Integer read FValue;
  end;

  TInt64Option = class(TOptionBase)
  private
    FValue: Int64;
  public
    procedure Apply(const AValue: string); override;
    function FormatForHelp: string; override;

    function ValueOr(const ADefault: Int64): Int64;

    property Value: Int64 read FValue;
  end;

  TRepeatableOption = class(TOptionBase)
  private
    FValues: TStringList;
  public
    constructor Create(const ALongName, AHelpText: string; const AGroup: string = '');
    destructor Destroy; override;

    procedure Apply(const AValue: string); override;
    function FormatForHelp: string; override;

    property Values: TStringList read FValues;
  end;

  TEnumOption<T> = class(TOptionBase)
  private
    FOrdinal: Integer;
    FPrefixLength: Integer;
    function JoinStrippedNames(const ASeparator: string): string;
  public
    constructor Create(const ALongName, AHelpText: string; const AGroup: string = '';
      const APrefixLength: Integer = 2);

    procedure Apply(const AValue: string); override;
    function FormatForHelp: string; override;
    function ValidValues: string; override;

    function Value: T;
    function ValueOr(const ADefault: T): T;
    function Matches(const AValue: T): Boolean;
  end;

  { Owns every option added to it and frees them when it is freed. }
  TOptionList = class
  private
    FItems: TOptionArray;
    FCount: Integer;
  public
    constructor Create;
    destructor Destroy; override;

    function AddFlag(const ALongName, AHelpText: string;
      const AGroup: string = ''): TFlagOption;
    function AddString(const ALongName, AHelpText: string;
      const AGroup: string = ''): TStringOption;
    function AddInteger(const ALongName, AHelpText: string;
      const AGroup: string = ''): TIntegerOption;
    function AddRepeatable(const ALongName, AHelpText: string;
      const AGroup: string = ''): TRepeatableOption;
    function Add(const AOption: TOptionBase): TOptionBase;

    function Options: TOptionArray;
  end;

function ConcatOptions(const AArrays: array of TOptionArray): TOptionArray;

{ A name as help lists it: ALongForm (`--output=<value>`), led by
  `-<AShortName>, ` when there is a short name. Option help and top-level
  flag help both use it, so the two help screens agree. }
function FormatHelpLabel(const AShortName, ALongForm: string): string;

implementation

function FormatHelpLabel(const AShortName, ALongForm: string): string;
begin
  if AShortName = '' then
    Result := ALongForm
  else
    Result := '-' + AShortName + ', ' + ALongForm;
end;

function ConcatOptions(const AArrays: array of TOptionArray): TOptionArray;
var
  TotalLength: Integer;
  I, J, Offset: Integer;
begin
  TotalLength := 0;
  for I := 0 to High(AArrays) do
    TotalLength := TotalLength + Length(AArrays[I]);

  SetLength(Result, TotalLength);
  Offset := 0;
  for I := 0 to High(AArrays) do
    for J := 0 to High(AArrays[I]) do
    begin
      Result[Offset] := AArrays[I][J];
      Inc(Offset);
    end;
end;

{ TOptionBase }

constructor TOptionBase.Create(const ALongName, AHelpText: string;
  const AGroup: string);
begin
  inherited Create;
  FLongName := ALongName;
  FShortName := '';
  FConfigName := '';
  FHelpText := AHelpText;
  FGroup := AGroup;
  FPresent := False;
  FFromCommandLine := False;
  FAllowAttachedShortValue := False;
end;

procedure TOptionBase.MarkFromCommandLine;
begin
  FFromCommandLine := True;
end;

procedure TOptionBase.MarkPresent;
begin
  FPresent := True;
end;

function TOptionBase.HelpLabel: string;
begin
  Result := FormatHelpLabel(FShortName, FormatForHelp);
end;

function TOptionBase.ValidValues: string;
begin
  Result := '';
end;

procedure TOptionBase.ApplyExplicit(const AValue: string;
  const AHasEquals: Boolean);
begin
  Apply(AValue);
end;

function TOptionBase.ConsumesSeparateValue: Boolean;
begin
  Result := True;
end;

{ TFlagOption }

procedure TFlagOption.Apply(const AValue: string);
begin
  FPresent := True;
end;

function TFlagOption.ConsumesSeparateValue: Boolean;
begin
  Result := False;
end;

function TFlagOption.FormatForHelp: string;
begin
  Result := '--' + LongName;
end;

{ TStringOption }

procedure TStringOption.Apply(const AValue: string);
begin
  FValue := AValue;
  FPresent := True;
end;

function TStringOption.FormatForHelp: string;
begin
  Result := '--' + LongName + '=<value>';
end;

function TStringOption.ValueOr(const ADefault: string): string;
begin
  if FPresent then
    Result := FValue
  else
    Result := ADefault;
end;

{ TOptionalStringOption }

procedure TOptionalStringOption.Apply(const AValue: string);
begin
  inherited Apply(AValue);
  FHasValue := True;
end;

procedure TOptionalStringOption.ApplyExplicit(const AValue: string;
  const AHasEquals: Boolean);
begin
  { The virtual Apply, so a subclass's override sees every occurrence;
    HasValue is then set from what the argument spelled. An attached
    short value (`-Hrestart`) carries a value without `=`. }
  Apply(AValue);
  FHasValue := AHasEquals or (AValue <> '');
end;

function TOptionalStringOption.ConsumesSeparateValue: Boolean;
begin
  Result := False;
end;

function TOptionalStringOption.FormatForHelp: string;
begin
  Result := '--' + LongName + '[=<value>]';
end;

{ TIntegerOption }

procedure TIntegerOption.Apply(const AValue: string);
var
  Parsed: Integer;
begin
  if not TryStrToInt(AValue, Parsed) then
    raise TParseError.CreateFmt('Invalid integer value for --%s: %s',
      [LongName, AValue]);
  FValue := Parsed;
  FPresent := True;
end;

function TIntegerOption.FormatForHelp: string;
begin
  Result := '--' + LongName + '=<N>';
end;

function TIntegerOption.ValueOr(const ADefault: Integer): Integer;
begin
  if FPresent then
    Result := FValue
  else
    Result := ADefault;
end;

{ TInt64Option }

procedure TInt64Option.Apply(const AValue: string);
var
  Parsed: Int64;
begin
  if not TryStrToInt64(AValue, Parsed) then
    raise TParseError.CreateFmt('Invalid integer value for --%s: %s',
      [LongName, AValue]);
  FValue := Parsed;
  FPresent := True;
end;

function TInt64Option.FormatForHelp: string;
begin
  Result := '--' + LongName + '=<N>';
end;

function TInt64Option.ValueOr(const ADefault: Int64): Int64;
begin
  if FPresent then
    Result := FValue
  else
    Result := ADefault;
end;

{ TRepeatableOption }

constructor TRepeatableOption.Create(const ALongName, AHelpText: string;
  const AGroup: string);
begin
  inherited Create(ALongName, AHelpText, AGroup);
  FValues := TStringList.Create;
end;

destructor TRepeatableOption.Destroy;
begin
  FValues.Free;
  inherited Destroy;
end;

procedure TRepeatableOption.Apply(const AValue: string);
begin
  FValues.Add(AValue);
  FPresent := True;
end;

function TRepeatableOption.FormatForHelp: string;
begin
  Result := '--' + LongName + ' <value>';
end;

{ TEnumOption<T> }

constructor TEnumOption<T>.Create(const ALongName, AHelpText: string;
  const AGroup: string; const APrefixLength: Integer);
begin
  inherited Create(ALongName, AHelpText, AGroup);
  FOrdinal := 0;
  FPrefixLength := APrefixLength;
end;

function TEnumOption<T>.JoinStrippedNames(
  const ASeparator: string): string;
var
  TypeData: PTypeData;
  I: Integer;
  EnumName: string;
  Stripped: string;
begin
  TypeData := GetTypeData(TypeInfo(T));
  Result := '';
  for I := TypeData^.MinValue to TypeData^.MaxValue do
  begin
    EnumName := GetEnumName(TypeInfo(T), I);
    Stripped := LowerCase(Copy(EnumName, FPrefixLength + 1,
      Length(EnumName) - FPrefixLength));
    if Result <> '' then
      Result := Result + ASeparator;
    Result := Result + Stripped;
  end;
end;

procedure TEnumOption<T>.Apply(const AValue: string);
var
  TypeData: PTypeData;
  I: Integer;
  EnumName: string;
  LowerValue: string;
begin
  TypeData := GetTypeData(TypeInfo(T));
  LowerValue := LowerCase(AValue);

  for I := TypeData^.MinValue to TypeData^.MaxValue do
  begin
    EnumName := GetEnumName(TypeInfo(T), I);
    if LowerCase(Copy(EnumName, FPrefixLength + 1,
       Length(EnumName) - FPrefixLength)) = LowerValue then
    begin
      FOrdinal := I;
      FPresent := True;
      Exit;
    end;
  end;

  raise TParseError.CreateFmt('Invalid value for --%s: %s (valid: %s)',
    [LongName, AValue, JoinStrippedNames(', ')]);
end;

function TEnumOption<T>.Value: T;
begin
  Move(FOrdinal, Result, SizeOf(T));
end;

function TEnumOption<T>.ValueOr(const ADefault: T): T;
begin
  if FPresent then
    Result := Value
  else
    Result := ADefault;
end;

function TEnumOption<T>.Matches(const AValue: T): Boolean;
var
  OrdinalValue: Integer;
begin
  OrdinalValue := 0;
  Move(AValue, OrdinalValue, SizeOf(T));
  Result := FPresent and (FOrdinal = OrdinalValue);
end;

function TEnumOption<T>.ValidValues: string;
begin
  Result := JoinStrippedNames(', ');
end;

function TEnumOption<T>.FormatForHelp: string;
begin
  Result := '--' + LongName + '=' + JoinStrippedNames('|');
end;

{ TOptionList }

constructor TOptionList.Create;
begin
  inherited Create;
end;

destructor TOptionList.Destroy;
var
  I: Integer;
begin
  for I := 0 to FCount - 1 do
    FItems[I].Free;
  inherited Destroy;
end;

function TOptionList.AddFlag(const ALongName, AHelpText: string;
  const AGroup: string): TFlagOption;
begin
  Result := TFlagOption.Create(ALongName, AHelpText, AGroup);
  Add(Result);
end;

function TOptionList.AddString(const ALongName, AHelpText: string;
  const AGroup: string): TStringOption;
begin
  Result := TStringOption.Create(ALongName, AHelpText, AGroup);
  Add(Result);
end;

function TOptionList.AddInteger(const ALongName, AHelpText: string;
  const AGroup: string): TIntegerOption;
begin
  Result := TIntegerOption.Create(ALongName, AHelpText, AGroup);
  Add(Result);
end;

function TOptionList.AddRepeatable(const ALongName, AHelpText: string;
  const AGroup: string): TRepeatableOption;
begin
  Result := TRepeatableOption.Create(ALongName, AHelpText, AGroup);
  Add(Result);
end;

function TOptionList.Add(const AOption: TOptionBase): TOptionBase;
begin
  { Grow geometrically so a long run of Add calls stays linear. }
  if FCount = Length(FItems) then
    SetLength(FItems, 2 * FCount + 4);
  FItems[FCount] := AOption;
  Inc(FCount);
  Result := AOption;
end;

function TOptionList.Options: TOptionArray;
begin
  Result := Copy(FItems, 0, FCount);
end;

end.
