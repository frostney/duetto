# Repository Orchestration Policy

LWPT's agent-orchestration policy, subordinate to [`AGENTS.md`](./AGENTS.md)
and repository security policy. The known-good-route skills own delivery:
`/deliver` publishes, merges, and verifies integration; `/address-feedback`
converges review; `delivery-wait` awaits GitHub state; milestone-rush fans out
work. This file declares only what those skills need from LWPT
([ADR-0046](./docs/adr/0046-skill-owned-delivery.md)).

## Capability classes and routing

Lanes run on the known-good-route
[capability tiers](./.agents/skills/milestone-rush/references/orchestration.md#capability-tiers)
(`mechanical`, `bounded`, `open`), which name no model, provider, or effort
level. LWPT narrows them: security work and independent review always run
`open`.

## Context packets

Workers start with no inherited conversation history. A packet carries the
applicable decision IDs and their settled text, issue or PR identity, branch
and exact head, owned scope, dependencies, acceptance criteria, required gates,
capability tier, and the structured result expected back. Add the three to
five most recent turns only when they are immediately relevant. Full-history
inheritance needs a recorded, scoped exception.

## Token checkpoints and interventions

Context occupancy is one inference's input tokens divided by the active
context window. Track the rolling median over the lane's latest ten inferences.

- Median greater than 40%: record a warning and choose to continue,
  checkpoint, split, replace, or escalate.
- Median greater than 55%: checkpoint durable state, then split or replace the
  lane before another inference.
- 25th consecutive inference without a durable transition (a settled decision,
  a new exact head, or a validation, review, PR, or merge state change): record
  and carry out a continue, split, replace, or escalate decision before
  inference 26.

An intervention never silently stops required work or downgrades capability.

## Monitoring and waits

Await GitHub state with `delivery-wait` or address-feedback's `review_wait.py`,
never with model heartbeats. A monitor makes at most three inferences without
an external state change, then hands the wait to a non-LLM command. Time-based
wakes use the exact reported timestamp.

A lane never waits more than five minutes inside its own context. Before a
longer wait (CI, a queued build or test run, a release workflow, or a
usage-limit reset), it checkpoints durable state, hands the wait to the
coordinator or a non-LLM watcher, and ends its turn. It resumes when the
result arrives. Hosts may expire a lane's context cache within minutes; the
next turn after an expiry rewrites the whole context.

## Escalation

Escalate to the maintainer for a material product or architecture decision,
missing authority, new infrastructure or spending, or policy that is malformed
or contradictory. Name the exact rule and evidence, keep the durable work, and
do not spawn lanes under guessed semantics.

## Review evidence

Review evidence is an independent review that the delivering agent runs on a
separate `open` lane against the exact head. It runs before the PR is
declared ready and again after every material change. Every review covers the
standards and specification axes. Changes to trust surfaces (network, TLS,
registry, install, lockfile, process isolation) add a security axis. Earlier
findings are revalidated against the new head before they are fixed or
dismissed, and the review report is recorded in the PR body by updating its
matching section in place, not in comments. On a PR someone other than the
authenticated user opened, the report is instead a comment from the
authenticated user: a new comment when a head brings findings that change what
the author must do, and an edit to the latest such comment when a re-check only
confirms fixes. CodeRabbit is advisory: its valid findings are addressed, but
its verdict is not required.

## Lane-admission preflight

FPC 3.2.2 silently truncates paths longer than 255 characters in compiler
staging, linking, and gzip archive opens
([#309](https://github.com/frostney/lwpt/issues/309)). Before adopting or
creating a worktree, run this from its root; it must succeed:

```sh
test "$(pwd -P | tr -d '\n' | wc -c)" -le 64
```

Evidence: a traced `./build/lwpt test --no-cache` of `917c174` gunzipped an
archive 187 characters below the root (`InstallGitGraph.Test.pas`) and
compiled into staging 186 characters below it (`TestCache.Test.pas`). The
255-character limit leaves 68; 64 keeps room for wider process IDs in
temporary names. `BuildSessions.Test.pas` builds an over-limit path on purpose
and does not count. Relocate a longer candidate to a shorter path before
implementation or a local gate; never learn this limit from failing tests.

## Integration and merge

- **Destination:** `main`. A delivery is integrated when the push run of
  `ci.yml` on its squash commit concludes green.
- **Required check:** `delivery-admission` from `ci.yml` on the exact head,
  with every review thread resolved. `ci.yml` runs the full native matrix on
  every PR, so there is no separate full-CI rule. Branches need not be up to
  date with `main`. Merge a single PR with
  `gh pr merge --squash --match-head-commit <sha>`, so a later push cannot slip
  past the review evidence; a native stack merges through `git-workflow`.
- **Main stays green:** a failed push run of `ci.yml` on `main` stops merges
  until `main` is fixed, as `git-workflow`'s default-branch health gate
  describes.
- **Review policy:** `.github/delivery/review-automations.json` lists no
  hosted automations, so `/address-feedback` waits only on review threads.
  The review evidence above is still required.
- **Diagnostics** (`gh workflow run diagnostic.yml --ref <branch> -f
  diagnostic_target=<target> -f diagnostic_selector=<selector>`) are
  remediation, never proof.
